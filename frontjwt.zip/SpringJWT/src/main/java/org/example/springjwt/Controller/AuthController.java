package org.example.springjwt.Controller;

import org.example.springjwt.Models.AuthResponse;
import org.example.springjwt.Models.ResponseMessage;
import org.example.springjwt.Models.Usuario;
import org.example.springjwt.Repository.UserRepository;
import org.example.springjwt.Security.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.userdetails.User;

import java.util.Collections;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {
    private final JwtTokenUtil jwtTokenUtil = new JwtTokenUtil();
    private final UserRepository userRepository;

    @Autowired
    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
     User userf ;


    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Usuario usuario) {
        Usuario foundUser = userRepository.findByUsername(usuario.getUsername());
        if (foundUser == null) {
            return ResponseEntity.status(401).body("Invalid username");
        }
        if (!usuario.getPassword().equals(foundUser.getPassword())) {
            return ResponseEntity.status(401).body("Invalid password");
        }


        User userDetails = new User(foundUser.getUsername(), foundUser.getPassword(), Collections.emptyList());
        userf = userDetails;
        String token = jwtTokenUtil.generateToken(userDetails);

        return ResponseEntity.ok(new AuthResponse(token));
    }
    @CrossOrigin(origins = "http://localhost:5173")
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Usuario usuario) {
        Usuario newUser = new Usuario(usuario.getUsername(), usuario.getPassword());
        userRepository.save(newUser);
        return ResponseEntity.ok(new ResponseMessage("Registro registrado con exito"));
    }
    @CrossOrigin(origins = "http://localhost:5173")
    @GetMapping("/Hola")
    public ResponseEntity<?> getAll() {

        String token = jwtTokenUtil.generateToken(userf);
        return ResponseEntity.ok().body(userf);
    }
}
