package org.example.springjwt.Models;

public class ResponseMessage {
    private String message;


    // Constructor
    public ResponseMessage(String message) {
        this.message = message;

    }

    // Getters and setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


}
