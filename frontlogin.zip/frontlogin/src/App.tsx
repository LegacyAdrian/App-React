
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from "./Components/LogIn.tsx";
import ProtectedPage from "./Components/ProtectedPage.tsx";
import Register from "./Components/Register.tsx";


const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/protectedpage" element={<ProtectedPage />} />
                <Route path="/register" element={<Register/>}/>
            </Routes>
        </Router>
    );
};

export default App;
