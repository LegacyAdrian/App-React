import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
// @ts-ignore
import '../Estilos.css';
import * as React from "react";
import {User} from "../types";


const Login:React.FC = () => {

    const [inputData, setInputData] = useState<User>({
        username : "",
        password: ""
    });
    const navigate = useNavigate()

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8081/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            });

            if (!response.ok) {
                setInputData({
                    username: "",
                    password: ""
                })
                throw new Error('Credenciales inválidas');
            }

            const data = await response.json();
            localStorage.setItem('jwtToken', data.token);
            alert('Login exitoso');
            navigate("/protectedpage")

        } catch (error) {
            console.error('Error de autenticación', error);
        }
    };

    const onHandle = (e :  React.ChangeEvent<HTMLInputElement>)=> {
        const {name, value} = e.target;
        setInputData({
            ...inputData,
            [name]: value
        });
    }

    useEffect(() => {
        console.log(inputData)
    }, [inputData])


    return (

        <div className="cartel">
            <h1>Log In</h1>
            <form onSubmit={handleLogin}>
                <label>Username</label>
                <input
                    name="username"
                    value={inputData.username}
                    type="text"
                    onChange={(event) => onHandle(event)}
                />
                <label>Password</label>
                <input
                    name="password"
                    value={inputData.password}
                    type="password"
                    onChange={(event) => onHandle(event)}
                />
                <button type="submit">Log In</button>
                <label onClick={()=>{navigate("/register")}}>If u dont have acount Sign in here!!</label>
            </form>
        </div>

    );
};

export default Login;
