import { useState } from "react";
import {useNavigate} from "react-router-dom";
// @ts-ignore
import '../Estilos.css';
import {User} from "../types";



const Register = () => {

    const [username, setName] = useState<User["username"]>('');
    const [password, setPassword] = useState<User["password"]>('');
    const navigate = useNavigate()

    const handleRegister = async (e: React.FormEvent):Promise<void> => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8081/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },

                body: JSON.stringify({ username, password }),
            });

            if (!response.ok) {
                throw new Error('Dato Erroneo');
            }

            alert('Registro exitoso');
            navigate("/login")

        } catch (error) {
            console.error('Error de autenticación', error);
        }
    };


    return (

        <div className="cartel">
            <form onSubmit={handleRegister}>
                <h1>Sign In</h1>
                <label>Username</label>
                <input
                    value={username}
                    type="text"
                    onChange={(event) : void => setName(event.target.value)}
                />
                <label>Password</label>
                <input
                    value={password}
                    type="password"
                    onChange={(event):void => setPassword(event.target.value)}
                />
                <button type="submit">Log In</button>
            </form>
        </div>

    );
};

export default Register;
