
export const fetchProtectedData = async ():Promise<void> => {
    const token = localStorage.getItem('jwtToken');

    if (!token) {
        console.log("No token found, please log in first.");
        return;
    }

    try {
        const response = await fetch('http://localhost:8081/auth/Hola', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
            //mode: 'no-cors'
        });

        if (!response.ok) {
            throw new Error('No autorizado o sesión expirada');
        }

        const data = await response.json();
        console.log(data);
        return data;

    } catch (error) {
        console.error('Error al obtener datos protegidos', error);
    }
};
