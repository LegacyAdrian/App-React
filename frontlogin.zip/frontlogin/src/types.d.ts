export interface User {
    username: string
    password: string
}
export type UserName = Pick<User,"username">
export type UserPassword = Pick<User,"password">